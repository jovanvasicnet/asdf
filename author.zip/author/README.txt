
TITLE: 
Author - 100% Fully Responsive One Page HTML5 Template

AUTHOR:
DESIGNED & DEVELOPED by FreeHTML5.co

Website: http://freehtml5.co/
Twitter: http://twitter.com/fh5co
Facebook: http://facebook.com/fh5co


CREDITS:

jQuery
http://jquery.com/

Slick Slider
http://kenwheeler.github.io/slick/

Demo Images:
http://unsplash.com

